package com.mousemobile.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.Build
import java.util.UUID
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Палитра: чистый чёрный (AMOLED) и тёмно-красный. */
private object Pal {
    val BG = Color.BLACK
    val CARD = Color.parseColor("#0D0D0D")
    val RED = Color.parseColor("#8B0000")
    val RED_HI = Color.parseColor("#B71C1C")
    val LINE = Color.parseColor("#3A0000")
    val TEXT = Color.parseColor("#E6E6E6")
    val MUTED = Color.parseColor("#8A8A8A")
}

class MainActivity : Activity() {

    private var inMain = false
    private var held = false
    private var fullscreen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Net.onLost = {
            runOnUiThread {
                if (inMain) showConnect("Соединение потеряно")
            }
        }
        showSplash()
    }

    private fun showSplash() {
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(com.mousemobile.app.R.mipmap.ic_launcher)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(104), dp(104)))
            addView(label("MouseMobile", 27f, Pal.RED_HI).apply {
                typeface = Typeface.DEFAULT_BOLD
                gravity = android.view.Gravity.CENTER
            }, lp(18))
            addView(label("Управление ПК по Wi-Fi", 14f, Pal.MUTED).apply {
                gravity = android.view.Gravity.CENTER
            }, lp(4))
        }
        setContentView(splash)
        Handler(Looper.getMainLooper()).postDelayed({
            showConnect()
            showInstructions()
        }, 2500L)
    }

    private fun showInstructions() {
        AlertDialog.Builder(this)
            .setTitle("Как подключиться")
            .setMessage("1. Запусти MouseMobile Server на компьютере.\n\n2. Подключи телефон и ПК к одной Wi-Fi сети.\n\n3. Нажми «Найти ПК и подключиться». При первой привязке введи шестизначный PIN с экрана компьютера.\n\nПосле привязки устройство запоминается на 7 дней.")
            .setPositiveButton("Я всё понял", null)
            .show()
    }

    private fun setFullscreen(enabled: Boolean) {
        fullscreen = enabled
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (enabled) {
            (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onDestroy() {
        setFullscreen(false)
        Net.onLost = null
        Net.disconnect()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inMain) showConnect() else super.onBackPressed()
    }

    // ---------- помощники оформления ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun shape(fill: Int, stroke: Int, radius: Int = 10): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun rippled(fill: Int): RippleDrawable = RippleDrawable(
        ColorStateList.valueOf(Color.parseColor("#66FF4040")),
        shape(fill, Pal.LINE),
        shape(Color.WHITE, Color.WHITE)
    )

    private fun label(t: String, size: Float, color: Int = Pal.TEXT): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
        }

    private fun button(t: String, fill: Int = Pal.RED, onClick: (Button) -> Unit): Button =
        Button(this).apply {
            text = t
            isAllCaps = false
            textSize = 15f
            setTextColor(Pal.TEXT)
            background = rippled(fill)
            stateListAnimator = null
            minWidth = 0
            minHeight = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { onClick(this) }
        }

    private fun field(ph: String, type: Int, value: String = ""): EditText =
        EditText(this).apply {
            hint = ph
            setText(value)
            inputType = type
            setTextColor(Pal.TEXT)
            setHintTextColor(Pal.MUTED)
            background = shape(Pal.CARD, Pal.LINE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(top) }

    private fun weight(margin: Int = 2): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            setMargins(dp(margin), dp(margin), dp(margin), dp(margin))
        }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    // ---------- экран подключения ----------

    private fun showConnect(msg: String = "") {
        setFullscreen(false)
        inMain = false
        held = false
        Net.disconnect()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = getSharedPreferences("mm", Context.MODE_PRIVATE)

        val status = label(msg, 14f, Pal.RED_HI)
        val find = button("Найти ПК и подключиться", Pal.RED) { b ->
            b.isEnabled = false
            status.text = "Ищем компьютер в Wi-Fi сети…"
            Thread {
                val found = Net.discover()
                if (found == null) {
                    runOnUiThread {
                        b.isEnabled = true
                        status.text = "Компьютер не найден. Проверьте, что сервер запущен и оба устройства в одной Wi-Fi сети."
                    }
                } else {
                    runOnUiThread { status.text = "Найден ${found.name} (${found.ip}). Подключаемся…" }
                    runOnUiThread {
                        val savedToken = prefs.getString("auth_token", "") ?: ""
                        val deviceId = prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("device_id", it).apply() }
                        val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android-устройство" }
                        if (savedToken.isNotBlank()) {
                            Thread {
                                val (err, _) = Net.connect(found.ip, savedToken, id = deviceId, name = deviceName)
                                runOnUiThread {
                                    b.isEnabled = true
                                    if (err == null) {
                                        prefs.edit().putString("pc_name", found.name).putString("pc_ip", found.ip).apply()
                                        showMain(found.name, found.ip)
                                    } else {
                                        prefs.edit().remove("auth_token").apply()
                                        status.text = "$err. Для новой привязки нажмите ещё раз и введите PIN с компьютера."
                                    }
                                }
                            }.start()
                        } else {
                            val pinField = field("Шестизначный PIN с экрана ПК", InputType.TYPE_CLASS_NUMBER)
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle("Первая привязка")
                                .setMessage("Введите одноразовый PIN, показанный сервером MouseMobile на компьютере. После привязки PIN больше не понадобится.")
                                .setView(pinField)
                                .setNegativeButton("Отмена") { _, _ -> b.isEnabled = true }
                                .setPositiveButton("Привязать") { _, _ ->
                                    val pin = pinField.text.toString().trim()
                                    if (pin.length != 6) { b.isEnabled = true; status.text = "Введите 6 цифр PIN" }
                                    else Thread {
                                        val (err, token) = Net.connect(found.ip, "", pin, deviceId, deviceName)
                                        runOnUiThread {
                                            b.isEnabled = true
                                            if (err == null && !token.isNullOrBlank()) {
                                                prefs.edit().putString("auth_token", token).putString("pc_name", found.name).putString("pc_ip", found.ip).apply()
                                                showMain(found.name, found.ip)
                                            } else status.text = err ?: "Не удалось сохранить привязку"
                                        }
                                    }.start()
                                }.show()
                        }
                    }
                }
            }.start()
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
            setPadding(dp(24), dp(48), dp(24), dp(24))
            addView(label("MouseMobile", 32f, Pal.RED_HI).apply { typeface = Typeface.DEFAULT_BOLD })
            addView(label("Управление ПК по Wi-Fi", 14f, Pal.MUTED))
            addView(find, lp(32))
            addView(label("Телефон и компьютер должны быть в одной Wi-Fi сети. При первой привязке введите одноразовый PIN с экрана ПК. После этого приложение будет подключаться автоматически в течение 7 дней.", 13f, Pal.MUTED), lp(12))
            addView(status, lp(16))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Pal.BG)
            isFillViewport = true
            addView(col)
        })
    }

    // ---------- основной экран ----------

    private fun showMain(pcName: String, pcIp: String) {
        inMain = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pad = TouchView(this, false)
        val screen = TouchView(this, true)
        val keys = keyboardTab()
        val views = listOf<View>(pad, keys, screen)
        val fullButton = button("Во весь экран", Pal.RED) {
            setFullscreen(!fullscreen)
            it.text = if (fullscreen) "Выйти из полного экрана" else "Во весь экран"
            screen.setFillScreen(fullscreen)
        }.apply { textSize = 13f }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(button("ЛКМ") { Net.send("CLICK left") }, weight())
        bar.addView(button("Удерж.", Pal.CARD) { b ->
            held = !held
            Net.send(if (held) "DOWN left" else "UP left")
            b.text = if (held) "Отпустить" else "Удерж."
            b.background = rippled(if (held) Pal.RED else Pal.CARD)
        }, weight())
        bar.addView(button("ПКМ") { Net.send("CLICK right") }, weight())

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabBtns = ArrayList<Button>()

        fun showTab(i: Int) {
            for ((k, v) in views.withIndex()) {
                v.visibility = if (k == i) View.VISIBLE else View.GONE
            }
            bar.visibility = if (i == 1) View.GONE else View.VISIBLE
            fullButton.visibility = if (i == 2) View.VISIBLE else View.GONE
            if (i != 2 && fullscreen) setFullscreen(false)
            for ((k, b) in tabBtns.withIndex()) {
                b.background = rippled(if (k == i) Pal.RED else Pal.CARD)
            }
            if (i == 2) {
                Net.startScreen(
                    { screen.showFrame(it) },
                    { m ->
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, m, Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            } else {
                Net.stopScreen()
            }
            hideKeyboard()
        }

        listOf("Тачпад", "Ввод", "Экран").forEachIndexed { i, name ->
            val b = button(name, Pal.CARD) { showTab(i) }
            tabBtns.add(b)
            tabs.addView(b, weight())
        }
        tabs.addView(
            button("✕", Pal.CARD) { showConnect() },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        )

        val body = FrameLayout(this)
        for (v in views) body.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        val screenLayer = FrameLayout(this)
        screenLayer.addView(screen, FrameLayout.LayoutParams(MATCH, MATCH))
        screenLayer.addView(fullButton, FrameLayout.LayoutParams(WRAP, WRAP, android.view.Gravity.TOP or android.view.Gravity.END).apply {
            setMargins(dp(8), dp(8), dp(8), dp(8))
        })
        body.removeView(screen)
        body.addView(screenLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        val connectionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(4))
            background = shape(Pal.CARD, Pal.LINE)
            addView(label("Подключено к: $pcName\n$pcIp", 12f, Pal.MUTED), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(button("Сбросить привязку", Pal.CARD) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Сбросить привязку?")
                    .setMessage("Телефон забудет этот компьютер, соединение будет закрыто. Для повторного подключения потребуется новый PIN с компьютера.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Сбросить") { _, _ ->
                        val prefs = getSharedPreferences("mm", Context.MODE_PRIVATE)
                        prefs.edit().remove("auth_token").remove("pc_name").remove("pc_ip").apply()
                        Net.unpair()
                        showConnect("Привязка сброшена. Подключитесь заново и введите новый PIN с ПК.")
                    }.show()
            }.apply { textSize = 12f }, LinearLayout.LayoutParams(WRAP, WRAP))
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            addView(connectionBar, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) })
            addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
            addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        })
        showTab(0)
    }

    private fun keyboardTab(): View {
        val input = field(
            "Текст для ввода на ПК",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        )
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            addView(input, lp())
            addView(button("Отправить текст") {
                val s = input.text.toString()
                if (s.isNotEmpty()) {
                    Net.send("TEXT " + Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                    input.setText("")
                }
            }, lp(8))
        }
        val rows = listOf(
            listOf("Esc" to "esc", "Tab" to "tab", "⌫" to "backspace", "Enter" to "enter", "Del" to "delete"),
            listOf("←" to "left", "↑" to "up", "↓" to "down", "→" to "right", "Space" to "space"),
            listOf("Win" to "win", "Alt+Tab" to "alt+tab", "Win+D" to "win+d", "Ctrl+C" to "ctrl+c", "Ctrl+V" to "ctrl+v"),
            listOf("Гр.−" to "volume_down", "Гр.+" to "volume_up", "Mute" to "volume_mute", "Пауза" to "play_pause", "След." to "next_track")
        )
        for (r in rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((name, key) in r) {
                row.addView(
                    button(name, Pal.CARD) { Net.send("KEY $key") }.apply { textSize = 13f },
                    weight()
                )
            }
            col.addView(row, lp(6))
        }
        return ScrollView(this).apply { addView(col) }
    }
}
