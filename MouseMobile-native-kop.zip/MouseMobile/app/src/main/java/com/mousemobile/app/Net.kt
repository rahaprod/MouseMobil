package com.mousemobile.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.Base64

/**
 * Сеть: управляющее соединение (команды мыши/клавиатуры), поток экрана и поиск ПК.
 * connect() и discover() блокирующие — вызывать только из фонового потока.
 */
data class PcInfo(val ip: String, val name: String)

object Net {
    private const val CTRL_PORT = 8765
    private const val SCREEN_PORT = 8766
    private const val DISCOVERY_PORT = 8767

    private val sender = Executors.newSingleThreadExecutor()

    @Volatile private var ctrl: Socket? = null
    @Volatile private var screen: Socket? = null
    @Volatile private var screenThread: Thread? = null
    @Volatile private var host = ""
    @Volatile private var authToken = ""
    @Volatile private var deviceId = ""
    @Volatile private var deviceName = "Android-устройство"

    /** Вызывается из фонового потока, когда соединение оборвалось. */
    @Volatile var onLost: (() -> Unit)? = null

    private fun readLine(input: InputStream): String {
        val sb = StringBuilder()
        while (sb.length < 64) {
            val c = input.read()
            if (c < 0 || c == '\n'.code) break
            sb.append(c.toChar())
        }
        return sb.toString().trim()
    }

    private fun handshake(s: Socket, token: String, pin: String = ""): String {
        val out = s.getOutputStream()
        val encodedName = Base64.getEncoder().encodeToString(deviceName.toByteArray(Charsets.UTF_8))
        val command = if (token.isNotBlank()) "AUTH $token $deviceId $encodedName\n" else "PAIR $pin $deviceId $encodedName\n"
        out.write(command.toByteArray(Charsets.UTF_8)); out.flush()
        return readLine(s.getInputStream())
    }

    /** Возвращает Pair(ошибка, новый токен). */
    fun connect(address: String, savedToken: String, pin: String = "", id: String, name: String): Pair<String?, String?> {
        disconnect(); deviceId = id; deviceName = name; var s: Socket? = null
        try {
            s = Socket(); s.connect(InetSocketAddress(address, CTRL_PORT), 3000)
            s.tcpNoDelay = true; s.soTimeout = 5000
            val reply = handshake(s, savedToken, pin)
            val newToken = if (reply.startsWith("TOKEN ")) reply.removePrefix("TOKEN ").trim() else null
            if (reply != "OK" && newToken == null) {
                s.close()
                return (if (reply == "NO") "PIN неверен, уже использован или привязка истекла" else "Нет ответа от сервера") to null
            }
            s.soTimeout = 0; host = address; authToken = newToken ?: savedToken; ctrl = s
            return null to newToken
        } catch (e: Exception) {
            try { s?.close() } catch (_: Exception) { }
            return ("Не удалось подключиться: " + (e.message ?: e.javaClass.simpleName)) to null
        }
    }

    /** Отправка команды в фоне, чтобы не трогать сеть из главного потока. */
    fun send(line: String) {
        val s = ctrl ?: return
        sender.execute {
            try {
                val out = s.getOutputStream()
                out.write((line + "\n").toByteArray(Charsets.UTF_8))
                out.flush()
            } catch (e: IOException) {
                if (ctrl === s) {
                    disconnect()
                    onLost?.invoke()
                }
            }
        }
    }

    fun disconnect() {
        stopScreen()
        val s = ctrl
        ctrl = null
        try { s?.close() } catch (_: Exception) { }
    }

    /** Удаляет привязку на сервере и локально закрывает соединение. */
    fun unpair() {
        val s = ctrl
        try {
            s?.getOutputStream()?.apply {
                write("UNPAIR\n".toByteArray(Charsets.UTF_8))
                flush()
            }
            Thread.sleep(120)
        } catch (_: Exception) { }
        disconnect()
    }

    /** Запускает приём кадров экрана ПК. onFrame/onEnd вызываются из фонового потока. */
    fun startScreen(onFrame: (Bitmap) -> Unit, onEnd: (String) -> Unit) {
        stopScreen()
        val address = host
        val t = Thread {
            val s = Socket()
            screen = s
            try {
                s.connect(InetSocketAddress(address, SCREEN_PORT), 3000)
                s.tcpNoDelay = true
                s.soTimeout = 8000
                if (handshake(s, authToken) != "OK") throw IOException("доступ запрещён")
                val input = DataInputStream(s.getInputStream().buffered())
                while (true) {
                    val n = input.readInt()
                    if (n <= 0 || n > 8_000_000) throw IOException("плохой кадр")
                    val buf = ByteArray(n)
                    input.readFully(buf)
                    val bmp = BitmapFactory.decodeByteArray(buf, 0, n)
                    if (bmp != null) onFrame(bmp)
                }
            } catch (e: Exception) {
                if (screen === s) onEnd("Экран: " + (e.message ?: "соединение закрыто"))
            } finally {
                try {
                    s.close()
                } catch (e: Exception) {
                }
            }
        }
        t.isDaemon = true
        screenThread = t
        t.start()
    }

    fun stopScreen() {
        val s = screen
        screen = null
        screenThread?.interrupt()
        screenThread = null
        try {
            s?.close()
        } catch (e: Exception) {
        }
    }

    /** Ищет ПК широковещательным запросом. Возвращает IP или null. */
    fun discover(): PcInfo? {
        return try {
            DatagramSocket().use { s ->
                s.broadcast = true
                s.soTimeout = 1500
                val msg = "MOUSEMOBILE?".toByteArray()
                s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("255.255.255.255"), DISCOVERY_PORT))
                val p = DatagramPacket(ByteArray(128), 128)
                s.receive(p)
                val response = String(p.data, 0, p.length).trim()
                if (response.startsWith("MOUSEMOBILE ")) PcInfo(p.address.hostAddress ?: "", response.removePrefix("MOUSEMOBILE ").trim()) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
