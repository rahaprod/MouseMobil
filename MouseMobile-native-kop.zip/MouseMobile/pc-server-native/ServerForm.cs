using System.Drawing;
using System.Windows.Forms;

namespace MouseMobileServer;

internal sealed class ServerForm : Form
{
    private readonly Label _pin = new();
    private readonly ListView _devices = new();
    private readonly System.Windows.Forms.Timer _timer = new();
    private readonly Color _bg = Color.FromArgb(9, 9, 9);
    private readonly Color _card = Color.FromArgb(20, 20, 20);
    private readonly Color _red = Color.FromArgb(183, 28, 28);
    private readonly Color _text = Color.FromArgb(235, 235, 235);
    private readonly Color _muted = Color.FromArgb(145, 145, 145);

    public ServerForm()
    {
        Text = "MouseMobile Server";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(760, 500);
        Size = new Size(900, 590);
        BackColor = _bg;
        ForeColor = _text;
        Font = new Font("Segoe UI", 10f);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(22), BackColor = _bg };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        Controls.Add(root);

        var title = new Label { Text = "MouseMobile Server", Dock = DockStyle.Fill, Font = new Font("Segoe UI", 22f, FontStyle.Bold), ForeColor = _text, TextAlign = ContentAlignment.MiddleLeft };
        root.Controls.Add(title, 0, 0);

        var pinPanel = new Panel { Dock = DockStyle.Fill, BackColor = _card, Padding = new Padding(16) };
        root.Controls.Add(pinPanel, 0, 1);
        var pinTitle = new Label { Text = "одноразовый PIN для новой привязки", Dock = DockStyle.Top, Height = 26, ForeColor = _muted };
        pinPanel.Controls.Add(pinTitle);
        _pin.Text = Program.CurrentPin;
        _pin.Dock = DockStyle.Left;
        _pin.Width = 210;
        _pin.Font = new Font("Segoe UI", 28f, FontStyle.Bold);
        _pin.ForeColor = Color.FromArgb(255, 70, 70);
        _pin.TextAlign = ContentAlignment.MiddleLeft;
        pinPanel.Controls.Add(_pin);
        var newPin = MakeButton("Сгенерировать новый PIN", 220, 42);
        newPin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        newPin.Location = new Point(pinPanel.Width - 245, 42);
        newPin.Click += (_, _) => { Program.GenerateNewPin(); RefreshData(); };
        pinPanel.Controls.Add(newPin);
        pinPanel.Resize += (_, _) => newPin.Location = new Point(pinPanel.ClientSize.Width - newPin.Width - 12, 42);

        var devicePanel = new Panel { Dock = DockStyle.Fill, BackColor = _bg };
        root.Controls.Add(devicePanel, 0, 2);
        var deviceTitle = new Label { Text = "подключённые устройства", Dock = DockStyle.Top, Height = 42, Font = new Font("Segoe UI", 14f, FontStyle.Bold), ForeColor = _text, TextAlign = ContentAlignment.MiddleLeft };
        _devices.Dock = DockStyle.Fill;
        _devices.View = View.Details;
        _devices.FullRowSelect = true;
        _devices.GridLines = false;
        _devices.MultiSelect = false;
        _devices.HideSelection = false;
        _devices.BackColor = _card;
        _devices.ForeColor = _text;
        _devices.BorderStyle = BorderStyle.None;
        _devices.Columns.Add("Устройство", 250);
        _devices.Columns.Add("Статус", 115);
        _devices.Columns.Add("IP-адрес", 145);
        _devices.Columns.Add("Доступ до", 175);
        devicePanel.Controls.Add(_devices);
        devicePanel.Controls.Add(deviceTitle);

        var footer = new Panel { Dock = DockStyle.Fill, BackColor = _bg };
        root.Controls.Add(footer, 0, 3);
        var disconnect = MakeButton("Отключить выбранное устройство", 270, 38);
        disconnect.Location = new Point(0, 5);
        disconnect.Click += (_, _) => DisconnectSelected();
        footer.Controls.Add(disconnect);
        var hint = new Label { Text = "сервер работает в локальной сети · Windows 10/11", Dock = DockStyle.Right, Width = 360, ForeColor = _muted, TextAlign = ContentAlignment.MiddleRight };
        footer.Controls.Add(hint);

        _timer.Interval = 1200;
        _timer.Tick += (_, _) => RefreshData();
        _timer.Start();
        RefreshData();
    }

    private Button MakeButton(string text, int width, int height) => new()
    {
        Text = text, Width = width, Height = height, FlatStyle = FlatStyle.Flat,
        BackColor = _red, ForeColor = Color.White, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
        Cursor = Cursors.Hand
    };

    private void RefreshData()
    {
        if (IsDisposed) return;
        _pin.Text = Program.CurrentPin;
        var rows = Program.GetDeviceRows();
        var selected = _devices.SelectedItems.Count > 0 ? _devices.SelectedItems[0].Tag as string : null;
        _devices.BeginUpdate();
        _devices.Items.Clear();
        foreach (var row in rows)
        {
            var item = new ListViewItem(row.Name);
            item.SubItems.Add(row.Status);
            item.SubItems.Add(row.Ip);
            item.SubItems.Add(row.Expires);
            item.Tag = row.Id;
            if (row.Status == "В сети") item.ForeColor = Color.FromArgb(130, 230, 150);
            _devices.Items.Add(item);
            if (selected == row.Id) item.Selected = true;
        }
        _devices.EndUpdate();
    }

    private void DisconnectSelected()
    {
        if (_devices.SelectedItems.Count == 0)
        {
            MessageBox.Show(this, "Сначала выберите устройство из списка.", "MouseMobile", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        var item = _devices.SelectedItems[0];
        var id = item.Tag as string;
        if (id is null) return;
        var answer = MessageBox.Show(this, $"Отключить «{item.Text}» и отозвать его доступ к компьютеру?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (answer != DialogResult.Yes) return;
        Program.DisconnectDevice(id);
        RefreshData();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _timer.Stop();
        base.OnFormClosed(e);
    }
}
