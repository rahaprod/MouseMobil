@echo off
setlocal
set "TARGET=%~dp0MouseMobile Server.exe"
if not exist "%TARGET%" (
  echo MouseMobile Server.exe not found. Extract the Windows Server package first.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup') + '\\MouseMobile Server.lnk'); $s.TargetPath='%TARGET%'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Autostart shortcut created for the current Windows user.
pause
