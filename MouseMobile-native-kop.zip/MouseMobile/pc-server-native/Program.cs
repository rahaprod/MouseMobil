using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Security.Cryptography;
using System.Text.Json;
using System.Collections.Concurrent;
using System.Windows.Forms;

namespace MouseMobileServer;

internal static class Program
{
    private const int CtrlPort = 8765, ScreenPort = 8766, DiscoveryPort = 8767;
    private const int Fps = 10, MaxWidth = 1280, JpegQuality = 55;
    private static readonly object AuthLock = new();
    private static readonly object StateLock = new();
    private static readonly string StatePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MouseMobile", "devices.json");
    private static string PairingCode = "";
    private sealed record DeviceState(string Id, string Name, string TokenHash, DateTime ExpiresUtc, string LastIp, DateTime LastSeenUtc);
    internal sealed record DeviceRow(string Id, string Name, string Status, string Ip, string Expires);
    private static readonly List<DeviceState> TrustedDevices = new();
    private static readonly ConcurrentDictionary<string, ConcurrentDictionary<TcpClient, byte>> Active = new();
    private static readonly object FailureLock = new();

    [STAThread]
    private static void Main()
    {
        if (!OperatingSystem.IsWindows())
        {
            MessageBox.Show("MouseMobile Server работает только в Windows 10/11.", "MouseMobile", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        try { SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch { }
        LoadPairingState();
        EnsurePairingCode();
        ApplicationConfiguration.Initialize();
        using var cts = new CancellationTokenSource();
        var tasks = new[] { RunTcp(CtrlPort, HandleControl, cts.Token), RunTcp(ScreenPort, HandleScreen, cts.Token), RunDiscovery(cts.Token) };
        Application.Run(new ServerForm());
        cts.Cancel();
        try { Task.WaitAll(tasks, TimeSpan.FromSeconds(3)); } catch { }
    }

    private static void EnsurePairingCode()
    {
        lock (AuthLock)
            if (PairingCode.Length != 6) PairingCode = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
    }

    internal static string CurrentPin { get { EnsurePairingCode(); lock (AuthLock) return PairingCode; } }
    internal static List<DeviceRow> GetDeviceRows()
    {
        lock (StateLock)
        {
            if (TrustedDevices.RemoveAll(d => d.ExpiresUtc <= DateTime.UtcNow) > 0) SavePairingState();
            return TrustedDevices.Select(d => new DeviceRow(d.Id, d.Name,
                Active.TryGetValue(d.Id, out var sockets) && !sockets.IsEmpty ? "В сети" : "Не в сети",
                d.LastIp, d.ExpiresUtc.ToLocalTime().ToString("dd.MM.yyyy HH:mm"))).ToList();
        }
    }
    internal static void GenerateNewPin()
    {
        lock (AuthLock) PairingCode = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
    }
    internal static void DisconnectDevice(string id)
    {
        lock (StateLock)
        {
            TrustedDevices.RemoveAll(d => d.Id == id);
            SavePairingState();
        }
        if (Active.TryRemove(id, out var sockets))
            foreach (var socket in sockets.Keys) try { socket.Close(); } catch { }
    }

    private static async Task RunTcp(int port, Func<TcpClient, NetworkStream, string, string, Task> handler, CancellationToken ct)
    {
        var listener = new TcpListener(IPAddress.Any, port);
        listener.Start();
        using var reg = ct.Register(() => listener.Stop());
        try
        {
            while (!ct.IsCancellationRequested)
            {
                TcpClient client;
                try { client = await listener.AcceptTcpClientAsync(ct); }
                catch (OperationCanceledException) { break; }
                _ = Task.Run(async () =>
                {
                    using (client)
                    {
                        client.NoDelay = true;
                        var ip = ((IPEndPoint)client.Client.RemoteEndPoint!).Address.ToString();
                        string? deviceId = null;
                        try
                        {
                            var stream = client.GetStream();
                            deviceId = await Authenticate(stream, ip, ct);
                            if (deviceId is null) return;
                            var bucket = Active.GetOrAdd(deviceId, _ => new ConcurrentDictionary<TcpClient, byte>());
                            bucket.TryAdd(client, 0);
                            try { await handler(client, stream, ip, deviceId); }
                            finally
                            {
                                bucket.TryRemove(client, out _);
                                if (bucket.IsEmpty && Active.TryGetValue(deviceId, out var current) && ReferenceEquals(current, bucket))
                                    Active.TryRemove(deviceId, out _);
                            }
                        }
                        catch (Exception ex) when (ex is IOException or SocketException or ObjectDisposedException or OperationCanceledException) { }
                    }
                }, CancellationToken.None);
            }
        }
        finally { listener.Stop(); }
    }

    private static async Task<string?> Authenticate(NetworkStream stream, string ip, CancellationToken ct)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(10));
        var line = await ReadLine(stream, timeout.Token);
        var parts = line.Split(' ', 4, StringSplitOptions.RemoveEmptyEntries);
        lock (AuthLock)
        {
            if (parts.Length >= 4 && parts[0] == "PAIR")
            {
                var supplied = parts[1]; var id = parts[2]; var name = DecodeName(parts[3]);
                if (PairingCode.Length == 6 && CryptographicEquals(supplied, PairingCode))
                {
                    var tokenBytes = RandomNumberGenerator.GetBytes(32);
                    var token = Convert.ToBase64String(tokenBytes).TrimEnd('=').Replace('+','-').Replace('/','_');
                    var device = new DeviceState(id, name, HashToken(token), DateTime.UtcNow.AddDays(7), ip, DateTime.UtcNow);
                    lock (StateLock)
                    {
                        TrustedDevices.RemoveAll(d => d.Id == id);
                        TrustedDevices.Add(device);
                        SavePairingState();
                    }
                    PairingCode = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
                    WriteLine(stream, "TOKEN " + token, ct).GetAwaiter().GetResult();
                    return id;
                }
            }
            else if (parts.Length >= 4 && parts[0] == "AUTH")
            {
                var token = parts[1]; var id = parts[2]; var name = DecodeName(parts[3]);
                lock (StateLock)
                {
                    var index = TrustedDevices.FindIndex(d => d.Id == id && d.ExpiresUtc > DateTime.UtcNow && CryptographicEquals(HashToken(token), d.TokenHash));
                    if (index >= 0)
                    {
                        var old = TrustedDevices[index];
                        TrustedDevices[index] = old with { Name = name, LastIp = ip, LastSeenUtc = DateTime.UtcNow };
                        SavePairingState();
                        WriteLine(stream, "OK", ct).GetAwaiter().GetResult();
                        return id;
                    }
                }
            }
            // Совместимость с предыдущей версией протокола: старые клиенты не получают новую привязку,
            // но действующие токены могут быть обновлены после выпуска нового APK.
        }
        await WriteLine(stream, "NO", ct);
        return null;
    }

    private static string DecodeName(string encoded)
    {
        try { return Encoding.UTF8.GetString(Convert.FromBase64String(encoded.Replace('-', '+').Replace('_', '/'))).Trim(); }
        catch { return "Android-устройство"; }
    }
    private static string HashToken(string token) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
    private static void LoadPairingState()
    {
        try
        {
            if (File.Exists(StatePath))
            {
                var loaded = JsonSerializer.Deserialize<List<DeviceState>>(File.ReadAllText(StatePath));
                if (loaded is not null) TrustedDevices.AddRange(loaded.Where(d => d.ExpiresUtc > DateTime.UtcNow));
            }
        }
        catch { TrustedDevices.Clear(); }
    }
    private static void SavePairingState()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(StatePath)!);
        File.WriteAllText(StatePath, JsonSerializer.Serialize(TrustedDevices));
    }
    private static bool CryptographicEquals(string a, string b)
    {
        var aa = Encoding.UTF8.GetBytes(a); var bb = Encoding.UTF8.GetBytes(b);
        return aa.Length == bb.Length && CryptographicOperations.FixedTimeEquals(aa, bb);
    }

    private static async Task HandleControl(TcpClient client, NetworkStream stream, string ip, string deviceId)
    {
        while (client.Connected)
        {
            var line = await ReadLine(stream, CancellationToken.None);
            if (line.Length == 0) break;
            if (line == "UNPAIR") { DisconnectDevice(deviceId); break; }
            try { ExecuteCommand(line); }
            catch (Exception ex) { Console.WriteLine("Ошибка команды: " + ex.Message); }
        }
        ReleaseLeftMouse();
    }

    private static async Task HandleScreen(TcpClient client, NetworkStream stream, string ip, string deviceId)
    {
        var delay = TimeSpan.FromMilliseconds(1000.0 / Fps);
        while (client.Connected)
        {
            var start = DateTime.UtcNow;
            using var bmp = CaptureScreen();
            using var scaled = ScaleIfNeeded(bmp, MaxWidth);
            using var ms = new MemoryStream();
            SaveJpeg(scaled, ms, JpegQuality);
            var data = ms.ToArray();
            var header = BitConverter.GetBytes(IPAddress.HostToNetworkOrder(data.Length));
            await stream.WriteAsync(header);
            await stream.WriteAsync(data);
            var wait = delay - (DateTime.UtcNow - start);
            if (wait > TimeSpan.Zero) await Task.Delay(wait);
        }
    }

    private static void ExecuteCommand(string line)
    {
        var split = line.IndexOf(' ');
        var cmd = split < 0 ? line : line[..split];
        var arg = split < 0 ? "" : line[(split + 1)..].Trim();
        switch (cmd)
        {
            case "MOVE":
                var d = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (d.Length == 2) MoveMouse(int.Parse(d[0]), int.Parse(d[1]));
                break;
            case "ABS":
                var p = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (p.Length == 2) MoveAbsolute(int.Parse(p[0]), int.Parse(p[1]));
                break;
            case "CLICK": ClickMouse(arg); break;
            case "DOWN": SetMouse(arg, true); break;
            case "UP": SetMouse(arg, false); break;
            case "SCROLL": MouseWheel(Math.Clamp(int.Parse(arg), -50, 50) * 120); break;
            case "TEXT": TypeText(Encoding.UTF8.GetString(Convert.FromBase64String(arg))); break;
            case "KEY": Hotkey(arg); break;
        }
    }

    private static Bitmap CaptureScreen()
    {
        var bounds = SystemInformation.VirtualScreen;
        var bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb);
        using var g = Graphics.FromImage(bmp);
        g.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy);
        return bmp;
    }

    private static Bitmap ScaleIfNeeded(Bitmap source, int maxWidth)
    {
        if (source.Width <= maxWidth) return (Bitmap)source.Clone();
        var height = (int)Math.Round(source.Height * (double)maxWidth / source.Width);
        var result = new Bitmap(maxWidth, height);
        using var g = Graphics.FromImage(result);
        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
        g.DrawImage(source, 0, 0, maxWidth, height);
        return result;
    }

    private static void SaveJpeg(Image image, Stream output, long quality)
    {
        var codec = ImageCodecInfo.GetImageEncoders().First(x => x.MimeType == "image/jpeg");
        using var parameters = new EncoderParameters(1);
        parameters.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
        image.Save(output, codec, parameters);
    }

    private static async Task RunDiscovery(CancellationToken ct)
    {
        using var udp = new UdpClient(DiscoveryPort);
        while (!ct.IsCancellationRequested)
        {
            UdpReceiveResult packet;
            try { packet = await udp.ReceiveAsync(ct); }
            catch (OperationCanceledException) { break; }
            var msg = Encoding.UTF8.GetString(packet.Buffer);
            if (msg.StartsWith("MOUSEMOBILE?", StringComparison.Ordinal))
            {
                var name = Encoding.UTF8.GetBytes("MOUSEMOBILE " + Environment.MachineName);
                await udp.SendAsync(name, packet.RemoteEndPoint);
            }
        }
    }

    private static async Task<string> ReadLine(Stream stream, CancellationToken ct)
    {
        var bytes = new List<byte>(128);
        var one = new byte[1];
        while (bytes.Count < 1_048_576)
        {
            var n = await stream.ReadAsync(one, ct);
            if (n == 0) break;
            if (one[0] == (byte)'\n') break;
            if (one[0] != (byte)'\r') bytes.Add(one[0]);
        }
        return Encoding.UTF8.GetString(bytes.ToArray()).Trim();
    }

    private static Task WriteLine(Stream stream, string line, CancellationToken ct) =>
        stream.WriteAsync(Encoding.UTF8.GetBytes(line + "\n"), ct).AsTask();

    private static string GetLocalIp()
    {
        using var s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        try { s.Connect("10.255.255.255", 1); return ((IPEndPoint)s.LocalEndPoint!).Address.ToString(); }
        catch { return "127.0.0.1"; }
    }

    // Win32 input
    private const uint InputMouse = 0, InputKeyboard = 1;
    private const uint MouseMove = 0x0001, MouseLeftDown = 0x0002, MouseLeftUp = 0x0004,
        MouseRightDown = 0x0008, MouseRightUp = 0x0010, MouseMiddleDown = 0x0020,
        MouseMiddleUp = 0x0040, MouseWheelFlag = 0x0800, MouseAbsolute = 0x8000, MouseVirtualDesk = 0x4000;
    private const uint KeyUp = 0x0002;

    [StructLayout(LayoutKind.Sequential)] private struct INPUT { public uint type; public InputUnion U; }
    [StructLayout(LayoutKind.Explicit)] private struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
    [StructLayout(LayoutKind.Sequential)] private struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)] private struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr dwExtraInfo; }
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")] private static extern bool SetProcessDpiAwarenessContext(IntPtr value);
    [DllImport("user32.dll")] private static extern int GetSystemMetrics(int index);

    private static void SendMouse(uint flags, int dx = 0, int dy = 0, uint data = 0) =>
        SendInput(1, new[] { new INPUT { type = InputMouse, U = new InputUnion { mi = new MOUSEINPUT { dx = dx, dy = dy, mouseData = data, dwFlags = flags } } } }, Marshal.SizeOf<INPUT>());
    private static void MoveMouse(int x, int y) => SendMouse(MouseMove, x, y);
    private static void MoveAbsolute(int x, int y)
    {
        var w = Math.Max(1, GetSystemMetrics(0)); var h = Math.Max(1, GetSystemMetrics(1));
        var nx = (int)Math.Clamp(x, 0, 10000) * 65535 / 10000;
        var ny = (int)Math.Clamp(y, 0, 10000) * 65535 / 10000;
        SendMouse(MouseMove | MouseAbsolute | MouseVirtualDesk, nx, ny);
    }
    private static uint MouseFlags(string button, bool down) => button switch
    {
        "left" => down ? MouseLeftDown : MouseLeftUp,
        "right" => down ? MouseRightDown : MouseRightUp,
        "middle" => down ? MouseMiddleDown : MouseMiddleUp,
        _ => 0
    };
    private static void SetMouse(string button, bool down) { var f = MouseFlags(button, down); if (f != 0) SendMouse(f); }
    private static void ClickMouse(string button) { SetMouse(button, true); SetMouse(button, false); }
    private static void ReleaseLeftMouse() => SetMouse("left", false);
    private static void MouseWheel(int delta) => SendMouse(MouseWheelFlag, data: unchecked((uint)delta));

    private static ushort Vk(string key)
    {
        var k = key.ToLowerInvariant();
        if (k.Length == 1)
        {
            char c = char.ToUpperInvariant(k[0]);
            if (c is >= 'A' and <= 'Z' or >= '0' and <= '9') return c;
        }
        if (k.Length >= 2 && k[0] == 'f' && int.TryParse(k[1..], out var fn) && fn is >= 1 and <= 12) return (ushort)(0x70 + fn - 1);
        return k switch
        {
            "enter" => 0x0D, "backspace" => 0x08, "tab" => 0x09, "esc" => 0x1B, "space" => 0x20,
            "up" => 0x26, "down" => 0x28, "left" => 0x25, "right" => 0x27, "delete" => 0x2E,
            "home" => 0x24, "end" => 0x23, "page_up" or "pageup" => 0x21, "page_down" or "pagedown" => 0x22,
            "ctrl" => 0x11, "alt" => 0x12, "shift" => 0x10, "win" or "cmd" => 0x5B,
            "volume_mute" => 0xAD, "volume_down" => 0xAE, "volume_up" => 0xAF,
            "play_pause" => 0xB3, "next_track" => 0xB0, "prev_track" => 0xB1,
            _ => 0
        };
    }
    private static void KeyPress(ushort vk)
    {
        if (vk == 0) return;
        var inputs = new[] {
            new INPUT { type = InputKeyboard, U = new InputUnion { ki = new KEYBDINPUT { wVk = vk } } },
            new INPUT { type = InputKeyboard, U = new InputUnion { ki = new KEYBDINPUT { wVk = vk, dwFlags = KeyUp } } }
        };
        SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
    }
    private static void Hotkey(string spec)
    {
        var keys = spec.Split('+').Select(Vk).ToArray();
        if (keys.Any(x => x == 0)) return;
        var inputs = new List<INPUT>();
        foreach (var k in keys) inputs.Add(new INPUT { type = InputKeyboard, U = new InputUnion { ki = new KEYBDINPUT { wVk = k } } });
        foreach (var k in keys.Reverse()) inputs.Add(new INPUT { type = InputKeyboard, U = new InputUnion { ki = new KEYBDINPUT { wVk = k, dwFlags = KeyUp } } });
        SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf<INPUT>());
    }
    private static void TypeText(string text)
    {
        foreach (var rune in text.EnumerateRunes())
        {
            var down = new INPUT { type = InputKeyboard, U = new InputUnion { ki = new KEYBDINPUT { wVk = 0, wScan = (ushort)rune.Value, dwFlags = 0x0004 } } };
            var up = new INPUT { type = InputKeyboard, U = new InputUnion { ki = new KEYBDINPUT { wVk = 0, wScan = (ushort)rune.Value, dwFlags = 0x0004 | KeyUp } } };
            SendInput(2, new[] { down, up }, Marshal.SizeOf<INPUT>());
        }
    }
}
