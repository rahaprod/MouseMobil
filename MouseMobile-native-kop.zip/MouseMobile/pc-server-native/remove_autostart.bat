@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MouseMobile Server.lnk" 2>nul
echo MouseMobile autostart removed.
pause
